-- AutoDeletus.lua

local AutoDeletus = CreateFrame("Frame")
AutoDeletus:RegisterEvent("ADDON_LOADED")
AutoDeletus:RegisterEvent("MERCHANT_SHOW")
AutoDeletus:RegisterEvent("BAG_UPDATE")

-- Color codes for print messages
local COLOR_GREEN = "|cff00ff00"
local COLOR_YELLOW = "|cffffff00"
local COLOR_RESET = "|r"

local rarityTable = {
  ["poor"] = 0,
  ["common"] = 1,
  ["uncommon"] = 2,
  ["rare"] = 3,
  ["epic"] = 4,
  ["legendary"] = 5,
  ["artifact"] = 6,
  ["heirloom"] = 7
}

local timer = CreateFrame("FRAME")
function setTimer(duration, func)
    local endTime = GetTime() + duration

    timer:SetScript("OnUpdate", function()
        if endTime < GetTime() then
            func()
            timer:SetScript("OnUpdate", nil)
        end
    end)
end

-- Configuration
local Config = {
    defaults = {
        enabled = true,
        sellToVendor = false,
        sellThreshold = 0.8,
        includedItems = {},
        excludedItems = {},
        rarity = 0,
        itemLevel = 0,
        itemTypes = {},
        silent = false,
    },

    SaveConfig = function(self, addon)
        AutoDeletusDB = addon.config
    end,

    ToggleSilent = function(self, addon, utility)
        addon.config.silent = not addon.config.silent
        self:SaveConfig(addon)
        if not addon.config.silent then
            utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: " .. COLOR_RESET .. "Silent mode disabled")
        end
    end,

    ToggleAddon = function(self, addon, utility)
        addon.config.enabled = not addon.config.enabled
        self:SaveConfig(addon)
        utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: " .. COLOR_RESET .. (addon.config.enabled and "Enabled" or "Disabled"))
    end,

    ToggleSellToVendor = function(self, addon, utility)
        addon.config.sellToVendor = not addon.config.sellToVendor
        self:SaveConfig(addon)
        utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Sell to vendor " .. COLOR_RESET .. (addon.config.sellToVendor and "enabled" or "disabled"))
    end,

    SetSellThreshold = function(self, addon, threshold, utility)
        addon.config.sellThreshold = threshold
        self:SaveConfig(addon)
        utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Sell threshold set to " .. COLOR_RESET .. threshold)
    end,

    AddIncludedItem = function(self, addon, itemName, utility)
        addon.config.includedItems[itemName] = true
        self:SaveConfig(addon)
        utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Added " .. COLOR_RESET .. itemName .. COLOR_YELLOW .. " to included items")
    end,

    RemoveIncludedItem = function(self, addon, itemName, utility)
        addon.config.includedItems[itemName] = nil
        self:SaveConfig(addon)
        utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Removed " .. COLOR_RESET .. itemName .. COLOR_YELLOW .. " from included items")
    end,

    AddExcludedItem = function(self, addon, itemName, utility)
        -- Ensure itemName is in the correct format (without brackets)
        itemName = string.gsub(itemName, "%[(.-)%]", "%1")
        addon.config.excludedItems = addon.config.excludedItems or {} -- Initialize the table if it's nil
        addon.config.excludedItems[itemName] = true
        self:SaveConfig(addon)
        utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Added " .. COLOR_RESET .. itemName .. COLOR_YELLOW .. " to excluded items")
    end,
  
  RemoveExcludedItem = function(self, addon, itemName, utility)
      -- Ensure itemName is in the correct format (without brackets)
      itemName = string.gsub(itemName, "%[(.-)%]", "%1")
      addon.config.excludedItems = addon.config.excludedItems or {} -- Initialize the table if it's nil
      addon.config.excludedItems[itemName] = nil
      self:SaveConfig(addon)
      utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Removed " .. COLOR_RESET .. itemName .. COLOR_YELLOW .. " from excluded items")
  end,

  ResetLists = function(self, addon, utility)
      addon.config.excludedItems = {}
      addon.config.includedItems = {}
      self:SaveConfig(addon)
      utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Excluded and included lists have been reset.")
  end,

    SetRarityFilter = function(self, addon, rarity, utility)
        addon.config.rarity = rarity
        self:SaveConfig(addon)
        utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Item rarity filter set to " .. COLOR_RESET .. rarity)
    end,

    SetItemLevelFilter = function(self, addon, itemLevel, utility)
        addon.config.itemLevel = itemLevel
        self:SaveConfig(addon)
        utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Item level filter set to " .. COLOR_RESET .. itemLevel)
    end,

    AddItemTypeFilter = function(self, addon, itemType, utility)
        addon.config.itemTypes[itemType] = true
        self:SaveConfig(addon)
        utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Added " .. COLOR_RESET .. itemType .. COLOR_YELLOW .. " to item type filter")
    end,

    RemoveItemTypeFilter = function(self, addon, itemType, utility)
        addon.config.itemTypes[itemType] = nil
        self:SaveConfig(addon)
        utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Removed " .. COLOR_RESET .. itemType .. COLOR_YELLOW .. " from item type filter")
    end,

    VendorAllItemsOfRarity = function(self, addon, rarity, utility)
      for bag = 0, 4 do
          for slot = 1, GetContainerNumSlots(bag) do
              local itemLink = GetContainerItemLink(bag, slot)
              if itemLink then
                  local _, _, itemRarity, _, _, _, _, _, _, _, itemSellPrice = GetItemInfo(itemLink)
                  if itemRarity == rarity and itemSellPrice > 0 then
                      UseContainerItem(bag, slot)
                      utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Sold item - " .. COLOR_RESET .. itemLink)

                      setTimer(1, function ()
                        
                      end)
                  end
              end
          end
      end
  end,
  
  VendorSoulboundItemsOfRarity = function(self, addon, rarity, utility)
      for bag = 0, 4 do
          for slot = 1, GetContainerNumSlots(bag) do
              local itemLink = GetContainerItemLink(bag, slot)
              if itemLink then
                  local _, _, itemRarity, _, _, _, _, _, _, _, itemSellPrice = GetItemInfo(itemLink)
                  if itemRarity == rarity and itemSellPrice > 0 then
                      local tooltip = CreateFrame("GameTooltip", "AutoDeletusTooltip", nil, "GameTooltipTemplate")
                      tooltip:SetOwner(WorldFrame, "ANCHOR_NONE")
                      tooltip:SetBagItem(bag, slot)
                      if tooltip:NumLines() > 0 then
                          for i = 1, tooltip:NumLines() do
                              local line = _G["AutoDeletusTooltipTextLeft" .. i]:GetText()
                              if line == ITEM_SOULBOUND then
                                  UseContainerItem(bag, slot)
                                  utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Sold soulbound item - " .. COLOR_RESET .. itemLink)
                                  setTimer(1, function ()
                        
                                  end)
                                  break
                              end
                          end
                      end
                      tooltip:Hide()
                  end
              end
          end
      end
  end,
  
  VendorBindsWhenEquippedItemsOfRarity = function(self, addon, rarity, utility)
      for bag = 0, 4 do
          for slot = 1, GetContainerNumSlots(bag) do
              local itemLink = GetContainerItemLink(bag, slot)
              if itemLink then
                  local _, _, itemRarity, _, _, _, _, _, _, _, itemSellPrice = GetItemInfo(itemLink)
                  if itemRarity == rarity and itemSellPrice > 0 then
                      local tooltip = CreateFrame("GameTooltip", "AutoDeletusTooltip", nil, "GameTooltipTemplate")
                      tooltip:SetOwner(WorldFrame, "ANCHOR_NONE")
                      tooltip:SetBagItem(bag, slot)
                      if tooltip:NumLines() > 0 then
                          for i = 1, tooltip:NumLines() do
                              local line = _G["AutoDeletusTooltipTextLeft" .. i]:GetText()
                              if line == ITEM_BIND_ON_EQUIP then
                                  UseContainerItem(bag, slot)
                                  utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Sold BoE item - " .. COLOR_RESET .. itemLink)
                                  setTimer(1, function ()
                        
                                  end)
                                  break
                              end
                          end
                      end
                      tooltip:Hide()
                  end
              end
          end
      end
  end,

  SortBagsByItemType = function(self, addon, utility)
    local itemTypeOrder = {
        ["Consumable"] = 1,
        ["Container"] = 2,
        ["Weapon"] = 3,
        ["Armor"] = 4,
        ["Reagent"] = 5,
        ["Projectile"] = 6,
        ["Trade Goods"] = 7,
        ["Recipe"] = 8,
        ["Quiver"] = 9,
        ["Quest"] = 10,
        ["Key"] = 11,
        ["Miscellaneous"] = 12,
    }

    local function getItemTypeOrder(itemType)
        return itemTypeOrder[itemType] or 9999 -- Default to a high number if not found
    end

    local function sortBagsByType()
        local itemTypes = {}

        -- Collect all items from bags and store them in itemTypes
        for bag = 0, 4 do
            for slot = 1, GetContainerNumSlots(bag) do
                local itemLink = GetContainerItemLink(bag, slot)
                if itemLink then
                    local _, _, _, _, _, itemType = GetItemInfo(itemLink)
                    if not itemTypes[itemType] then
                        itemTypes[itemType] = {}
                    end
                    table.insert(itemTypes[itemType], { bag = bag, slot = slot, itemLink = itemLink })
                end
            end
        end

        -- Sort itemTypes by itemTypeOrder
        local sortedTypes = {}
        for itemType, _ in pairs(itemTypes) do
            table.insert(sortedTypes, itemType)
        end
        table.sort(sortedTypes, function(a, b)
            return getItemTypeOrder(a) < getItemTypeOrder(b)
        end)

        -- Reorganize items within the bags based on the sorted types
        local currentBag, currentSlot = 0, 1
        for _, itemType in ipairs(sortedTypes) do
            for _, item in ipairs(itemTypes[itemType]) do
                while currentBag <= 4 do
                    local bagSlots = GetContainerNumSlots(currentBag)
                    while currentSlot <= bagSlots do
                        local itemLink = GetContainerItemLink(currentBag, currentSlot)
                        if not itemLink then
                            -- Empty slot found, move the item here
                            PickupContainerItem(item.bag, item.slot)
                            PickupContainerItem(currentBag, currentSlot)
                            currentSlot = currentSlot + 1
                            break
                        else
                            currentSlot = currentSlot + 1
                        end
                    end
                    if currentSlot > bagSlots then
                        -- Current bag is full, move to the next bag
                        currentBag = currentBag + 1
                        currentSlot = 1
                    else
                        -- Item placed in the current bag, exit the loop
                        break
                    end
                end
            end
        end
    end

    sortBagsByType()

    utility:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Bags sorted by item type.")
end

}

-- Utility
local Utility = {
  Print = function(self, addon, message)
      if not addon.config.silent then
          print(message)
      end
  end,

  MeetsDeletionCriteria = function(self, addon, itemLink, rarity)
    local itemName, _, itemRarity, itemLevel, _, _, itemType = GetItemInfo(itemLink)

    if itemName then
      itemName = string.gsub(itemName, "%[(.-)%]", "%1")
    end

    local isExcluded = false
    for excludedItemName, _ in pairs(addon.config.excludedItems) do
        excludedItemName = string.gsub(excludedItemName, "%[(.-)%]", "%1")
        if excludedItemName == itemName then
            isExcluded = true
            break
        end
    end

    -- Check if itemRarity and itemLevel are not nil
    if itemRarity and itemLevel then
        local configItemLevel = addon.config.itemLevel or 0
        local isItemType = addon.config.itemTypes and addon.config.itemTypes[itemType] or false

        return (itemRarity == rarity or isItemType)
            and (not addon.config.includedItems or not addon.config.includedItems[itemName])
            and (itemLevel <= configItemLevel or configItemLevel == 0)
            and not isExcluded
    else
        return false
    end
  end,

    DeleteItem = function(self, addon, itemLink)
        for bag = 0, 4 do
            for slot = 1, GetContainerNumSlots(bag) do
                local _, _, _, _, _, _, itemLink2 = GetContainerItemInfo(bag, slot)
                if itemLink2 == itemLink then
                    PickupContainerItem(bag, slot)
                    DeleteCursorItem()
                    self:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Deleted item - " .. COLOR_RESET .. itemLink)
                    return
                end
            end
        end
    end,

    SellItem = function(self, addon, itemLink)
        for bag = 0, 4 do
            for slot = 1, GetContainerNumSlots(bag) do
                local _, _, _, _, _, _, itemLink2 = GetContainerItemInfo(bag, slot)
                if itemLink2 == itemLink then
                    UseContainerItem(bag, slot)
                    self:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Sold item - " .. COLOR_RESET .. itemLink)
                    return
                end
            end
        end
    end,

    CanSellItem = function(self, itemLink)
        local _, _, _, _, _, _, _, _, _, _, itemSellPrice = GetItemInfo(itemLink)
        return itemSellPrice > 0
    end,

    VoidRarity = function(self, addon, rarity)
      local deletedCount = 0
      local rarityText = ""
      for rarityName, rarityValue in pairs(rarityTable) do
          if rarityValue == rarity then
              rarityText = rarityName
              break
          end
      end
  
      local function deleteItems(bag)
          for slot = 1, GetContainerNumSlots(bag) do
              local _, _, _, _, _, _, itemLink = GetContainerItemInfo(bag, slot)
              if itemLink and self:MeetsDeletionCriteria(addon, itemLink, rarity) then
                  PickupContainerItem(bag, slot)
                  DeleteCursorItem()
                  deletedCount = deletedCount + 1
                  setTimer(0.1, function ()                    
                    self:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: Voided " .. rarityText .. " item - " .. COLOR_RESET .. itemLink)
                  end)
                  return true
              end
          end
          return false
      end
  
      for bag = 0, 4 do
          deleteItems(bag)
      end
  
      if deletedCount == 0 then
          self:Print(addon, COLOR_YELLOW .. "[AutoDeletus]: No " .. rarityText .. " items were found to void." .. COLOR_RESET)
      end
  end,

    PrintUsage = function(self)
        print(COLOR_YELLOW .. "AutoDeletus commands:" .. COLOR_RESET)
        print("  /loot toggle - Toggle the addon on/off")
        print("  /loot selltovendor - Toggle selling to vendor")
        print("  /loot sellthreshold <threshold> - Set the selling threshold")
        print("  /loot include <itemName> - Add an item to the included items list")
        print("  /loot exclude <itemName> - Add an item to the excluded items list")
        print("  /loot removeinclude <itemName> - Remove an item from the included items list")
        print("  /loot removeexclude <itemName> - Remove an item from the excluded items list")
        print("  /loot rarity <rarity> - Set the item rarity filter (0-7)")
        print("  /loot itemlevel <itemLevel> - Set the item level filter")
        print("  /loot addtype <itemType> - Add an item type to the item type filter")
        print("  /loot removetype <itemType> - Remove an item type from the item type filter")
        print("  /loot void <rarity> - Delete all items of the specified rarity from the bag")
        print("  /loot config - Print the current configuration")
        print("  /loot silence - Toggle silent mode on/off")
        print("  /loot vendor <type> <rarity> - Sell items of the specified rarity and binding type (all, sb, be)")
        print("  /loot sort - Sort items in bags by item group")
    end,

    PrintConfig = function(self, addon)
        self:Print(addon, COLOR_YELLOW .. "AutoDeletus Configuration:" .. COLOR_RESET)
        self:Print(addon, "  Enabled: " .. tostring(addon.config.enabled))
        self:Print(addon, "  Sell to Vendor: " .. tostring(addon.config.sellToVendor))
        self:Print(addon, "  Sell Threshold: " .. addon.config.sellThreshold)
        
        -- Print included items
        local includedItems = {}
        for itemName, _ in pairs(addon.config.includedItems) do
            table.insert(includedItems, itemName)
        end
        self:Print(addon, "  Included Items: " .. table.concat(includedItems, ", "))
        
        -- Print excluded items
        local excludedItems = {}
        for itemName, _ in pairs(addon.config.excludedItems) do
            table.insert(excludedItems, itemName)
        end
        self:Print(addon, "  Excluded Items: " .. table.concat(excludedItems, ", "))
        
        self:Print(addon, "  Rarity Filter: " .. addon.config.rarity)
        self:Print(addon, "  Item Level Filter: " .. addon.config.itemLevel)
        
        -- Print item type filters
        local itemTypes = {}
        for itemType, _ in pairs(addon.config.itemTypes) do
            table.insert(itemTypes, itemType)
        end
        self:Print(addon, "  Item Type Filters: " .. table.concat(itemTypes, ", "))
        
        self:Print(addon, "  Silent Mode: " .. tostring(addon.config.silent))
    end
}

-- Addon configuration
AutoDeletus.config = {}

-- Event handler for ADDON_LOADED
function AutoDeletus:OnAddonLoaded(addonName)
  if addonName == "AutoDeletus" then
      -- Load saved configuration or initialize with defaults
      AutoDeletusDB = AutoDeletusDB or {}
      self.config = AutoDeletusDB
      for k, v in pairs(Config.defaults) do
          if self.config[k] == nil then
              self.config[k] = v
          end
      end

      -- Ensure rarity and itemLevel have valid values
      self.config.rarity = self.config.rarity or 0
      self.config.itemLevel = self.config.itemLevel or 0

      -- Initialize excluded items list if it doesn't exist
      self.config.excludedItems = self.config.excludedItems or {}

      print(COLOR_GREEN .. "AutoDeletus loaded. Type /loot for commands." .. COLOR_RESET)
    end
end

-- Event handler for MERCHANT_SHOW
function AutoDeletus:OnMerchantShow()
  if self.config.sellToVendor then
      for bag = 0, 4 do
          for slot = 1, GetContainerNumSlots(bag) do
              local itemLink = GetContainerItemLink(bag, slot)
              if itemLink then
                  local _, _, itemRarity = GetItemInfo(itemLink)
                  if itemRarity == 0 and Utility:MeetsDeletionCriteria(self, itemLink) and Utility:CanSellItem(itemLink) then
                      Utility:SellItem(self, itemLink)
                  end
              end
          end
      end
  end
end

-- Event handler for BAG_UPDATE
function AutoDeletus:OnBagUpdate()
    if not self.config.enabled then return end

    local deleteRarityZero = false

    for bag = 0, 4 do
        for slot = 1, GetContainerNumSlots(bag) do
            local itemLink = GetContainerItemLink(bag, slot)
            if itemLink then
                local _, _, itemRarity = GetItemInfo(itemLink)
                if itemRarity == 0 then
                    deleteRarityZero = true
                elseif Utility:MeetsDeletionCriteria(self, itemLink) then
                    if self.config.sellToVendor and Utility:CanSellItem(itemLink) and MerchantFrame:IsShown() then
                        Utility:SellItem(self, itemLink)
                    else
                        Utility:DeleteItem(self, itemLink)
                    end
                end
            end
        end
    end

    -- Delete all items of rarity 0 if there are any
    if deleteRarityZero then
        Utility:VoidRarity(self, 0)
    end
end

-- Register the event handlers
AutoDeletus:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        self:OnAddonLoaded(...)
    elseif event == "MERCHANT_SHOW" then
        self:OnMerchantShow()
    elseif event == "BAG_UPDATE" then
        self:OnBagUpdate()
    end
end)

-- Slash command handler
SLASH_AUTODELETUS1 = "/loot"
SlashCmdList["AUTODELETUS"] = function(msg)
    local command, args = msg:match("^(%S*)%s*(.-)$")
    if command == "toggle" then
        Config:ToggleAddon(AutoDeletus, Utility)
    elseif command == "selltovendor" then
        Config:ToggleSellToVendor(AutoDeletus, Utility)
    elseif command == "sellthreshold" then
        local threshold = tonumber(args)
        if threshold then
            Config:SetSellThreshold(AutoDeletus, threshold, Utility)
        end
    elseif command == "include" then
        Config:AddIncludedItem(AutoDeletus, args, Utility)
    elseif command == "exclude" then
        Config:AddExcludedItem(AutoDeletus, args, Utility)
    elseif command == "removeinclude" then
        Config:RemoveIncludedItem(AutoDeletus, args, Utility)
    elseif command == "removeexclude" then
        Config:RemoveExcludedItem(AutoDeletus, args, Utility)
    elseif command == "rarity" then
        rarity = tonumber(rarityTable[string.lower(args)])
        if rarity then
            Config:SetRarityFilter(AutoDeletus, rarity, Utility)
        end
    elseif command == "itemlevel" then
        local itemLevel = tonumber(args)
        if itemLevel then
            Config:SetItemLevelFilter(AutoDeletus, itemLevel, Utility)
        end
    elseif command == "addtype" then
        Config:AddItemTypeFilter(AutoDeletus, args, Utility)
    elseif command == "removetype" then
        Config:RemoveItemTypeFilter(AutoDeletus, args, Utility)
    elseif command == "void" then
        rarity = tonumber(rarityTable[string.lower(args)])
        if rarity then
            Utility:VoidRarity(AutoDeletus, rarity)
        end
    elseif command == "config" then
        Utility:PrintConfig(AutoDeletus)
    elseif command == "silence" then
        Config:ToggleSilent(AutoDeletus, Utility)
    elseif command == "reset" then
        Config:ResetLists(AutoDeletus, Utility)
    elseif command == "vendor" then
      local vendorType, rarity = strsplit(" ", args)

      rarity = tonumber(rarityTable[string.lower(rarity)])
      if vendorType == "all" then
          Config:VendorAllItemsOfRarity(AutoDeletus, rarity, Utility)
      elseif vendorType == "sb" then
          Config:VendorSoulboundItemsOfRarity(AutoDeletus, rarity, Utility)
      elseif vendorType == "be" then
          Config:VendorBindsWhenEquippedItemsOfRarity(AutoDeletus, rarity, Utility)
      end
    elseif command == "sort" then
      Config:SortBagsByItemType(AutoDeletus, Utility)
    else
      Utility:PrintUsage()
    end
end