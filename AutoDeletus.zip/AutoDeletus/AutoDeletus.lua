-- AutoDeletus.lua

local AutoDeletus = CreateFrame("Frame")
AutoDeletus:RegisterEvent("ADDON_LOADED")
AutoDeletus:RegisterEvent("MERCHANT_SHOW")
AutoDeletus:RegisterEvent("LOOT_OPENED")

-- Configuration
local Config = {
    defaults = {
        enabled = true,
        sellToVendor = false,
        sellThreshold = 0.8,
        includedItems = {},
        excludedItems = {},
        rarity = 0,
        itemLevel = 0,
        itemTypes = {},
    },

    SaveConfig = function(self, addon)
        AutoDeletusDB = addon.config
    end,

    ToggleAddon = function(self, addon)
        addon.config.enabled = not addon.config.enabled
        self:SaveConfig(addon)
        print("AutoDeletus: " .. (addon.config.enabled and "Enabled" or "Disabled"))
    end,

    ToggleSellToVendor = function(self, addon)
        addon.config.sellToVendor = not addon.config.sellToVendor
        self:SaveConfig(addon)
        print("AutoDeletus: Sell to vendor " .. (addon.config.sellToVendor and "enabled" or "disabled"))
    end,

    SetSellThreshold = function(self, addon, threshold)
        addon.config.sellThreshold = threshold
        self:SaveConfig(addon)
        print("AutoDeletus: Sell threshold set to " .. threshold)
    end,

    AddIncludedItem = function(self, addon, itemName)
        addon.config.includedItems[itemName] = true
        self:SaveConfig(addon)
        print("AutoDeletus: Added " .. itemName .. " to included items")
    end,

    RemoveIncludedItem = function(self, addon, itemName)
        addon.config.includedItems[itemName] = nil
        self:SaveConfig(addon)
        print("AutoDeletus: Removed " .. itemName .. " from included items")
    end,

    AddExcludedItem = function(self, addon, itemName)
        addon.config.excludedItems[itemName] = true
        self:SaveConfig(addon)
        print("AutoDeletus: Added " .. itemName .. " to excluded items")
    end,

    RemoveExcludedItem = function(self, addon, itemName)
        addon.config.excludedItems[itemName] = nil
        self:SaveConfig(addon)
        print("AutoDeletus: Removed " .. itemName .. " from excluded items")
    end,

    SetRarityFilter = function(self, addon, rarity)
        addon.config.rarity = rarity
        self:SaveConfig(addon)
        print("AutoDeletus: Item rarity filter set to " .. rarity)
    end,

    SetItemLevelFilter = function(self, addon, itemLevel)
        addon.config.itemLevel = itemLevel
        self:SaveConfig(addon)
        print("AutoDeletus: Item level filter set to " .. itemLevel)
    end,

    AddItemTypeFilter = function(self, addon, itemType)
        addon.config.itemTypes[itemType] = true
        self:SaveConfig(addon)
        print("AutoDeletus: Added " .. itemType .. " to item type filter")
    end,

    RemoveItemTypeFilter = function(self, addon, itemType)
        addon.config.itemTypes[itemType] = nil
        self:SaveConfig(addon)
        print("AutoDeletus: Removed " .. itemType .. " from item type filter")
    end,
}

-- Utility
local Utility = {
    MeetsDeletionCriteria = function(self, addon, itemLink)
        local itemName, _, itemRarity, itemLevel, _, _, itemType = GetItemInfo(itemLink)

        -- Check if itemRarity and itemLevel are not nil
        if itemRarity and itemLevel then
            local configItemLevel = addon.config.itemLevel or 0
            local configRarity = addon.config.rarity or 0
            local isExcluded = addon.config.excludedItems and addon.config.excludedItems[itemName] or false
            local isItemType = addon.config.itemTypes and addon.config.itemTypes[itemType] or false

            return (itemRarity <= configRarity or isExcluded or isItemType)
                and (not addon.config.includedItems or not addon.config.includedItems[itemName])
                and (itemLevel <= configItemLevel or configItemLevel == 0)
        else
            -- Handle the case when itemRarity or itemLevel is nil
            return false
        end
    end,

    DeleteItem = function(self, addon, itemLink)
        for bag = 0, 4 do
            for slot = 1, GetContainerNumSlots(bag) do
                local _, _, _, _, _, _, itemLink2 = GetContainerItemInfo(bag, slot)
                if itemLink2 == itemLink then
                    PickupContainerItem(bag, slot)
                    DeleteCursorItem()
                    return
                end
            end
        end
    end,

    SellItem = function(self, addon, itemLink)
        for bag = 0, 4 do
            for slot = 1, GetContainerNumSlots(bag) do
                local _, _, _, _, _, _, itemLink2 = GetContainerItemInfo(bag, slot)
                if itemLink2 == itemLink then
                    UseContainerItem(bag, slot)
                    print("AutoDeletus: Sold item - " .. itemLink)
                    return
                end
            end
        end
    end,

    CanSellItem = function(self, itemLink)
        local _, _, _, _, _, _, _, _, _, _, itemSellPrice = GetItemInfo(itemLink)
        return itemSellPrice > 0
    end,

    VoidRarity = function(self, addon, rarity)
        for bag = 0, 4 do
            for slot = 1, GetContainerNumSlots(bag) do
                local _, _, _, _, _, _, itemLink = GetContainerItemInfo(bag, slot)
                if itemLink then
                    local _, _, itemRarity, _, _, _, _, _, _, _, _ = GetItemInfo(itemLink)
                    if itemRarity == rarity then
                        PickupContainerItem(bag, slot)
                        DeleteCursorItem()
                        print("AutoDeletus: Voided item - " .. itemLink)
                    end
                end
            end
        end
    end,

    PrintUsage = function(self)
        print("AutoDeletus commands:")
        print("  /gae toggle - Toggle the addon on/off")
        print("  /gae selltovendor - Toggle selling to vendor")
        print("  /gae sellthreshold <threshold> - Set the selling threshold")
        print("  /gae include <itemName> - Add an item to the included items list")
        print("  /gae exclude <itemName> - Add an item to the excluded items list")
        print("  /gae removeinclude <itemName> - Remove an item from the included items list")
        print("  /gae removeexclude <itemName> - Remove an item from the excluded items list")
        print("  /gae rarity <rarity> - Set the item rarity filter (0-7)")
        print("  /gae itemlevel <itemLevel> - Set the item level filter")
        print("  /gae addtype <itemType> - Add an item type to the item type filter")
        print("  /gae removetype <itemType> - Remove an item type from the item type filter")
        print("  /gae void <rarity> - Delete all items of the specified rarity from the bag")
        print("  /gae config - Print the current configuration")
    end,

    PrintConfig = function(self, addon)
        print("AutoDeletus Configuration:")
        print("  Enabled: " .. tostring(addon.config.enabled))
        print("  Sell to Vendor: " .. tostring(addon.config.sellToVendor))
        print("  Sell Threshold: " .. addon.config.sellThreshold)
        print("  Included Items: " .. table.concat(addon.config.includedItems, ", "))
        print("  Excluded Items: " .. table.concat(addon.config.excludedItems, ", "))
        print("  Rarity Filter: " .. addon.config.rarity)
        print("  Item Level Filter: " .. addon.config.itemLevel)
        print("  Item Type Filters: " .. table.concat(addon.config.itemTypes, ", "))
    end,
}

-- Addon configuration
AutoDeletus.config = {}

-- Event handler for ADDON_LOADED
function AutoDeletus:OnAddonLoaded(addonName)
    if addonName == "AutoDeletus" then
        -- Load saved configuration or initialize with defaults
        AutoDeletusDB = AutoDeletusDB or {}
        self.config = AutoDeletusDB
        for k, v in pairs(Config.defaults) do
            if self.config[k] == nil then
                self.config[k] = v
            end
        end

        -- Ensure rarity and itemLevel have valid values
        self.config.rarity = self.config.rarity or 0
        self.config.itemLevel = self.config.itemLevel or 0

        print("AutoDeletus loaded. Type /gae for commands.")
        Utility:PrintConfig(self)  -- Print the current configuration
    end
end

-- Event handler for MERCHANT_SHOW
function AutoDeletus:OnMerchantShow()
    if self.config.sellToVendor then
        for bag = 0, 4 do
            for slot = 1, GetContainerNumSlots(bag) do
                local itemLink = GetContainerItemLink(bag, slot)
                if itemLink and Utility:MeetsDeletionCriteria(self, itemLink) and Utility:CanSellItem(itemLink) then
                    Utility:SellItem(self, itemLink)
                end
            end
        end
    end
end

-- Event handler for LOOT_OPENED
function AutoDeletus:OnLootOpened()
    if not self.config.enabled then return end

    for i = 1, GetNumLootItems() do
        local itemLink = GetLootSlotLink(i)
        if itemLink then
            local _, _, itemRarity = GetItemInfo(itemLink)
            if itemRarity == 0 then
                Utility:VoidRarity(self, 0)
            elseif Utility:MeetsDeletionCriteria(self, itemLink) then
                if self.config.sellToVendor and Utility:CanSellItem(itemLink) and MerchantFrame:IsShown() then
                    Utility:SellItem(self, itemLink)
                else
                    Utility:DeleteItem(self, itemLink)
                end
            end
        end
    end
end

-- Register the event handlers
AutoDeletus:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        self:OnAddonLoaded(...)
    elseif event == "MERCHANT_SHOW" then
        self:OnMerchantShow()
    elseif event == "LOOT_OPENED" then
        self:OnLootOpened()
    end
end)

-- Slash command handler
SLASH_AUTODELETEGREYTITEMS1 = "/gae"
SlashCmdList["AUTODELETEGREYTITEMS"] = function(msg)
    local command, args = msg:match("^(%S*)%s*(.-)$")
    if command == "toggle" then
        Config:ToggleAddon(AutoDeletus)
    elseif command == "selltovendor" then
        Config:ToggleSellToVendor(AutoDeletus)
    elseif command == "sellthreshold" then
        local threshold = tonumber(args)
        if threshold then
            Config:SetSellThreshold(AutoDeletus, threshold)
        end
    elseif command == "include" then
        Config:AddIncludedItem(AutoDeletus, args)
    elseif command == "exclude" then
        Config:AddExcludedItem(AutoDeletus, args)
    elseif command == "removeinclude" then
        Config:RemoveIncludedItem(AutoDeletus, args)
    elseif command == "removeexclude" then
        Config:RemoveExcludedItem(AutoDeletus, args)
    elseif command == "rarity" then
        local rarity = tonumber(args)
        if rarity then
            Config:SetRarityFilter(AutoDeletus, rarity)
        end
    elseif command == "itemlevel" then
        local itemLevel = tonumber(args)
        if itemLevel then
            Config:SetItemLevelFilter(AutoDeletus, itemLevel)
        end
    elseif command == "addtype" then
        Config:AddItemTypeFilter(AutoDeletus, args)
    elseif command == "removetype" then
        Config:RemoveItemTypeFilter(AutoDeletus, args)
    elseif command == "void" then
        local rarity = tonumber(args)
        if rarity then
            Utility:VoidRarity(AutoDeletus, rarity)
        end
    elseif command == "config" then
        Utility:PrintConfig(AutoDeletus)
    else
        Utility:PrintUsage()
    end
end