-- Initialize the Stealus addon
local Stealus = {}
Stealus.scanResults = {}

-- Define color codes
local COLOR_RED = "|cFFFF0000"
local COLOR_GREEN = "|cFF00FF00"
local COLOR_ORANGE = "|cFFFF8000"
local COLOR_RESET = "|r"

-- Event frame to handle auction house events
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("AUCTION_HOUSE_SHOW")
eventFrame:RegisterEvent("AUCTION_HOUSE_CLOSED")

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "AUCTION_HOUSE_SHOW" then
        Stealus:OnAuctionHouseShow()
    elseif event == "AUCTION_HOUSE_CLOSED" then
        Stealus:OnAuctionHouseClosed()
    elseif event == "AUCTION_ITEM_LIST_UPDATE" then
        Stealus:ProcessAuctionItems()
    end
end)

local timer = CreateFrame("FRAME")
function setTimer(duration, func)
    local endTime = GetTime() + duration

    timer:SetScript("OnUpdate", function()
        if endTime < GetTime() then
            -- Time is up
            func()
            timer:SetScript("OnUpdate", nil)
        end
    end)
end


function Stealus:OnAuctionHouseShow()
    -- Create the scan results frame
    self:CreateScanResultsFrame()
end

function Stealus:OnAuctionHouseClosed()
    -- Hide the scan results frame when auction house is closed
    if self.scanResultsFrame then
        self.scanResultsFrame:Hide()
    end
end

-- Update the StaticPopupDialogs table
StaticPopupDialogs["STEALUS_CONFIRM_BUY"] = {
  text = "Do you want to buy the item %s for %s?",
  button1 = "Yes",
  button2 = "No",
  OnAccept = function(self, data)
      self.data.response = "yes"
  end,
  OnCancel = function(self, data)
      self.data.response = "no"
  end,
  timeout = 0,
  whileDead = true,
  hideOnEscape = true,
  preferredIndex = 3,
}

function Stealus:CreateScanResultsFrame()
  -- Create the frame
  self.scanResultsFrame = CreateFrame("Frame", "StealusScanResultsFrame", UIParent)
  self.scanResultsFrame:SetSize(300, 400)
  self.scanResultsFrame:SetPoint("TOPLEFT", AuctionFrame, "TOPRIGHT", 10, 0)
  self.scanResultsFrame:SetBackdrop({
      bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
      edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
      tile = true,
      tileSize = 32,
      edgeSize = 32,
      insets = { left = 11, right = 12, top = 12, bottom = 11 }
  })
  self.scanResultsFrame:Hide()

  -- Create the scroll frame
  self.scrollFrame = CreateFrame("ScrollFrame", "StealusScrollFrame", self.scanResultsFrame, "UIPanelScrollFrameTemplate")
  self.scrollFrame:SetSize(280, 360)
  self.scrollFrame:SetPoint("TOP", 0, -20)

  -- Create the content frame
  self.contentFrame = CreateFrame("Frame", "StealusContentFrame", self.scrollFrame)
  self.contentFrame:SetSize(280, 360)
  self.scrollFrame:SetScrollChild(self.contentFrame)

  -- Create the content font string
  self.contentFontString = self.contentFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  self.contentFontString:SetPoint("TOPLEFT", 10, -10)
  self.contentFontString:SetJustifyH("LEFT")
  self.contentFontString:SetJustifyV("TOP")
end

function Stealus:UpdateScanResultsFrame()
    if not self.contentFontString then return end -- Ensure the contentFontString is initialized

    local resultsText = ""
    for _, item in ipairs(self.scanResults) do
        if item.itemLink then
            resultsText = resultsText .. item.itemLink .. "\n"
        end
    end
    self.contentFontString:SetText(resultsText)
    self.scanResultsFrame:Show()
end

SLASH_SELL1 = "/sell"
SlashCmdList["SELL"] = function(msg)
    local param, percentage = strsplit(" ", msg:trim())
    param = param:lower()
    percentage = tonumber(percentage) or 30
    
    if param == "all" then
        Stealus:SellusAll(percentage)
    elseif param:find("%[") then
        Stealus:SellusByName(param, percentage)
    else
        Stealus:SellusByRarity(param, percentage)
    end
end

SLASH_SCAN1 = "/scan"
SlashCmdList["SCAN"] = function(msg)
    local sellerName, buyAll = strsplit(" ", msg:trim())
    sellerName = sellerName:trim()
    if sellerName == "" then
        sellerName = nil
    end
    buyAll = buyAll == "all"
    Stealus:Scanus(sellerName, buyAll)
end

SLASH_SCANBID1 = "/bid"
SlashCmdList["SCANBID"] = function(msg)
    Stealus:ScanBidItems()
end

function Stealus:ScanBidItems()
  -- Check if the auction house is already open
  if AuctionFrame and AuctionFrame:IsVisible() then
      -- Find and click the "Browse" tab on the Auction House UI
      for i = 1, 3 do -- There are only 3 tabs in WoW 3.3.5 Auction House UI
          local tab = _G["AuctionFrameTab" .. i]
          if tab and tab:GetText() == BROWSE then
              tab:Click()
              break
          end
      end

      -- Clear previous scan results
      self.scanResults = {}

      -- Start the scanning process
      self:StartBidScanning()
  else
      print(COLOR_ORANGE .. "[Stealus] " .. COLOR_RED .. "Please open the auction house first." .. COLOR_RESET)
  end
end

function Stealus:StartBidScanning()
  -- Set the filters for the query
  local name = nil -- Empty string to match any item name
  local minLevel = 0
  local maxLevel = 80
  local invType = nil
  local class = nil
  local subclass = nil
  local currentPage = 0
  local usable = false
  local rarity = nil
  local exactMatch = false

  -- Register the AUCTION_ITEM_LIST_UPDATE event
  eventFrame:RegisterEvent("AUCTION_ITEM_LIST_UPDATE")
  eventFrame:SetScript("OnEvent", function(self, event, ...)
      if event == "AUCTION_ITEM_LIST_UPDATE" then
          -- Get the total number of auction items for the current query
          local totalAuctions = GetNumAuctionItems("list")

          -- Iterate through the auction items and check their bid price and buyout price
          for i = 1, totalAuctions do
              local name, _, count, _, _, _, minBid, minIncrement, buyoutPrice, bidAmount = GetAuctionItemInfo("list", i)
              local itemLink = GetAuctionItemLink("list", i)

              if itemLink and minBid > 0 and minBid <= 10000 and buyoutPrice > 20000 then
                  table.insert(self.scanResults, {
                      itemLink = itemLink,
                      stackSize = count,
                      bidPrice = minBid,
                      index = i
                  })
              end
          end

          -- Update the scan results frame
          Stealus:UpdateBidScanResultsFrame()

          -- Unregister the event and reset the script
          eventFrame:UnregisterEvent("AUCTION_ITEM_LIST_UPDATE")
          eventFrame:SetScript("OnEvent", nil)
      end
  end)

  -- Query the auction items with the specified filters for the first page
  QueryAuctionItems(name, minLevel, maxLevel, invType, class, subclass, currentPage, usable, rarity, exactMatch)
end

function Stealus:UpdateBidScanResultsFrame()
  if not self.contentFontString then return end -- Ensure the contentFontString is initialized

  local resultsText = ""
  for _, item in ipairs(self.scanResults) do
      local itemName, _, stackSize, bidPrice, index = item.itemLink, item.stackSize, item.bidPrice, item.index
      resultsText = resultsText .. itemLink .. " x" .. stackSize .. " " .. formatMoney(bidPrice) .. " "
      resultsText = resultsText .. "|cff00ff00[Bid]|r\n"
  end
  self.contentFontString:SetText(resultsText)
  self.scanResultsFrame:Show()
end

function Stealus:SellusAll(percentage)
  -- Scan bags for items of all rarities
  self.scanResults = {}
  for bag = 0, 4 do
      for slot = 1, GetContainerNumSlots(bag) do
          local itemLink = GetContainerItemLink(bag, slot)
          if itemLink and not self:IsItemExcluded(itemLink) and not self:IsItemSoulbound(bag, slot) and not self:IsItemQuest(bag, slot) then
              table.insert(self.scanResults, { itemLink = itemLink, bag = bag, slot = slot, percentage = percentage })
          end
      end
  end

  if #self.scanResults == 0 then
      print(COLOR_ORANGE .. "[Stealus] " .. COLOR_RED .. "No eligible items found in your bags." .. COLOR_RESET)
      return
  end

  Stealus:UpdateScanResultsFrame()
  -- Scan auction house for lowest prices and post auctions
  self:ScanAndPostAuctions(percentage)
end

function Stealus:SellusByName(itemName, percentage)
  -- Extract item name from link if provided as a link
  local itemNameFromLink = itemName:match("%[(.-)%]")
  if itemNameFromLink then
      itemName = itemNameFromLink
  end

  -- Trim whitespace from itemName
  itemName = itemName:trim()

  -- Scan bags for the specified item
  self.scanResults = {}
  for bag = 0, 4 do
      for slot = 1, GetContainerNumSlots(bag) do
          local itemLink = GetContainerItemLink(bag, slot)
          if itemLink then
              local name = GetItemInfo(itemLink)
              if name and self:IsMatchingItem(itemLink, itemName) and not self:IsItemExcluded(itemLink) and not self:IsItemSoulbound(bag, slot) and not self:IsItemQuest(bag, slot) then
                  table.insert(self.scanResults, { itemLink = itemLink, bag = bag, slot = slot, percentage = percentage })
              end
          end
      end
  end

  if #self.scanResults == 0 then
      print(COLOR_ORANGE .. "[Stealus] " .. COLOR_RED .. "No items matching '" .. itemName .. "' found in your bags or all matching items are excluded." .. COLOR_RESET)
      return
  end

  -- Scan auction house for lowest prices and post auctions
  self:ScanAndPostAuctions(percentage)
end

function Stealus:SellusByRarity(rarity, percentage)
  -- Convert rarity from string to number
  local rarityTable = {
      ["poor"] = 0,
      ["common"] = 1,
      ["uncommon"] = 2,
      ["rare"] = 3,
      ["epic"] = 4,
      ["legendary"] = 5,
      ["artifact"] = 6,
      ["heirloom"] = 7
  }
  local rarityValue = rarityTable[string.lower(rarity)]
  if not rarityValue then
      print(COLOR_RED .. "Invalid rarity specified. Available rarities: poor, common, uncommon, rare, epic, legendary, artifact, heirloom" .. COLOR_RESET)
      return
  end

  -- Scan bags for the specified rarity
  self.scanResults = {}
  for bag = 0, 4 do
      for slot = 1, GetContainerNumSlots(bag) do
          local itemLink = GetContainerItemLink(bag, slot)
          
          if itemLink and self:IsMatchingRarity(itemLink, rarityValue) and not self:IsItemExcluded(itemLink) and not self:IsItemSoulbound(bag, slot) and not self:IsItemQuest(bag, slot) then
              table.insert(self.scanResults, { itemLink = itemLink, bag = bag, slot = slot, percentage = percentage })
          end
      end
  end

  if #self.scanResults == 0 then
      print(COLOR_ORANGE .. "[Stealus] " .. COLOR_RED .. "No items matching rarity '" .. rarity .. "' found in your bags or all matching items are excluded." .. COLOR_RESET)
      return
  end

  Stealus:UpdateScanResultsFrame()
  -- Scan auction house for lowest prices and post auctions
  self:ScanAndPostAuctions(percentage)
end

function Stealus:IsItemQuest(bag, slot)
  local itemLink = GetContainerItemLink(bag, slot)
  if itemLink then
      local itemString = string.match(itemLink, "item[%-?%d:]+")
      local itemId = tonumber(string.match(itemString, "item:(%d+)"))
      if itemId then
          local itemName, _, _, _, _, itemType = GetItemInfo(itemId)
          return itemType == "Quest"
      end
  end
  return false
end

function Stealus:IsItemSoulbound(bag, slot)
  local _, _, _, _, _, _, itemLink = GetContainerItemInfo(bag, slot)
  if itemLink then
      local itemString = string.match(itemLink, "item[%-?%d:]+")
      local _, _, _, _, _, _, _, _, _, _, _, _, _, bindType = GetItemInfo(itemString)
      return bindType == 1 or bindType == 2 or bindType == 3
  end
  return false
end

function Stealus:IsMatchingItem(itemLink, itemName)
    local name = GetItemInfo(itemLink)
    if name then
        itemName = itemName:gsub("[%[%]]", ""):trim()
        name = name:trim()
        return name == itemName
    else
        return false
    end
end

function Stealus:IsMatchingRarity(itemLink, rarity)
    local _, _, itemRarity = GetItemInfo(itemLink)
    return itemRarity == rarity
end

function Stealus:ScanAndPostAuctions(percentage)
  local item = table.remove(self.scanResults, 1)
  if not item then
      print(COLOR_ORANGE .. "[Stealus] " .. COLOR_GREEN .. "Scanning finished." .. COLOR_RESET)
      return
  end

  self:ScanAuctionHouse(item, percentage)
end

function Stealus:ScanAuctionHouse(item, percentage)
  if not item then
      print("Invalid item parameter.")
      return
  end

  -- Fetch the itemLink dynamically
  local itemLink = GetContainerItemLink(item.bag, item.slot)
  if not itemLink then
      -- Item link couldn't be fetched, proceed to the next item
      Stealus:ScanAndPostAuctions(percentage)
      return
  end

  local itemName = GetItemInfo(itemLink)
  if not itemName then
      Stealus:ScanAndPostAuctions(percentage)
      return
  end

  self.currentItem = item -- Store the current item being processed

  QueryAuctionItems(itemName)
  eventFrame:RegisterEvent("AUCTION_ITEM_LIST_UPDATE")
end

local function formatMoney(amount)
  local gold = math.floor(amount / 10000)
  local silver = math.floor((amount % 10000) / 100)
  local copper = amount % 100
  
  local moneyString = ""
  if gold > 0 then
      moneyString = gold .. "g "
  end
  if silver > 0 then
      moneyString = moneyString .. silver .. "s "
  end
  if copper > 0 then
      moneyString = moneyString .. copper .. "c"
  end
  
  return moneyString:trim()
end

function Stealus:ProcessAuctionItems()
  eventFrame:UnregisterEvent("AUCTION_ITEM_LIST_UPDATE")

  local item = self.currentItem
  if not item then
      setTimer(1, function()
          Stealus:ScanAndPostAuctions(item.percentage)
      end)
      return
  end

  local itemLink = GetContainerItemLink(item.bag, item.slot)
  local itemName = nil

  if itemLink then
      itemName = GetItemInfo(itemLink)
  end

  if not itemName or self:IsItemExcluded(itemLink) or self:IsItemSoulbound(item.bag, item.slot) or self:IsItemQuest(item.bag, item.slot) then
      setTimer(1, function()
          Stealus:ScanAndPostAuctions(item.percentage)
      end)
      return
  end

  local lowestPrice = nil
  local ownerName = nil

  for i = 1, GetNumAuctionItems("list") do
      local name, _, count, _, _, _, _, _, buyoutPrice, _, _, owner = GetAuctionItemInfo("list", i)
      if name == itemName and buyoutPrice > 0 then
          local currentPrice = buyoutPrice / count
          if not lowestPrice or (currentPrice < lowestPrice) then
              lowestPrice = currentPrice
              ownerName = owner
          end
      end
  end

  if not lowestPrice then
      print(COLOR_ORANGE .. "[Stealus] " .. COLOR_RED .. "No auctions found for item: " .. itemName .. COLOR_RESET)
      
      -- Skip duplicate items
      while #self.scanResults > 0 and GetItemInfo(self.scanResults[1].itemLink) == itemName do
          table.remove(self.scanResults, 1)
      end
      
      setTimer(1, function()
          Stealus:ScanAndPostAuctions(item.percentage)
      end)
      return
  end

  local unitName = UnitName("player")
  local isOwner = ownerName == unitName
  local undercutPercentage = item.percentage / 100
  local undercutPrice = isOwner and lowestPrice or math.floor(lowestPrice * (1 - undercutPercentage))

  -- Get the stack size of the item in the bag
  local _, stackSize = GetContainerItemInfo(item.bag, item.slot)
  
  -- Multiply the undercut price by the stack size
  undercutPrice = undercutPrice * stackSize

  if undercutPrice <= 0 then
      setTimer(1, function()
          Stealus:ScanAndPostAuctions(item.percentage)
      end)
      return
  end

  local _, _, _, _, _, _, itemID = GetContainerItemInfo(item.bag, item.slot)

  if itemID then
      ClickAuctionSellItemButton()
      ClearCursor()
      PickupContainerItem(item.bag, item.slot)
      ClickAuctionSellItemButton()
      StartAuction(undercutPrice, undercutPrice, 48)

      print(COLOR_ORANGE .. "[Stealus]|r |cff00ff00Posted auction|r |cffffffff" .. itemLink .. " x" .. stackSize .. "|r |cff00ff00for:|r |cffffd700" .. formatMoney(undercutPrice) .. COLOR_RESET)
      Stealus:UpdateScanResultsFrame()

      setTimer(1, function()
          Stealus:ScanAndPostAuctions(item.percentage)
      end)
  else
      print(COLOR_ORANGE .. "[Stealus] " .. COLOR_RED .. "Item is not present in bag " .. item.bag .. " slot " .. item.slot .. COLOR_RESET)
      setTimer(1, function()
          Stealus:ScanAndPostAuctions(item.percentage)
      end)
  end
end

local ammunitionExclusions = {
  "Accurate Arrows",
  "Broad Arrows",
  "Crude Arrows",
  "Deadly Arrows",
  "Jagged Arrows",
  "Razor Arrows",
  "Sharp Arrows",
  "Wicked Arrows",
  "Accurate Bullets",
  "Solid Bullets",
  "Heavy Bullets",
  "Keen Bullets",
  "Deadly Bullets",
  "Wicked Bullets",
  "Adamantite Bullets",
  "Mithril Bullets",
  "Saronite Razorheads",
  -- Add more ammunition items to exclude here
}

function Stealus:IsItemExcluded(itemLink)
  local isExcluded = false
  if AutoDeletusDB and AutoDeletusDB.excludedItems then
      local itemName = GetItemInfo(itemLink)
      if itemName then
          for excludedItemLink, _ in pairs(AutoDeletusDB.excludedItems) do
              local excludedItemName = GetItemInfo(excludedItemLink)
              if excludedItemName and excludedItemName == itemName then
                  isExcluded = true
                  break
              end
          end
      end
  end
  return isExcluded
end

function Stealus:Scanus(sellerName, buyAll)
  local function onAuctionItemListUpdate()
      -- Get the total number of auction items
      local totalAuctions = GetNumAuctionItems("list")

      -- Helper function to check if a table contains a specific value
      function tContains(table, value)
          for _, v in pairs(table) do
              if v == value then
                  return true
              end
          end
          return false
      end

      -- Check if totalAuctions is a valid number
      if type(totalAuctions) == "number" then
          -- Iterate through the auction items and check their item level and price
          for i = 1, totalAuctions do
              local name, _, count, _, _, _, _, _, buyoutPrice, _, _, owner, _, _, _, _, _, _, auctionID = GetAuctionItemInfo("list", i)
              local itemLink = GetAuctionItemLink("list", i)
              if itemLink then
                  local _, _, _, itemLevel, _, _, _, _, itemEquipLoc, _, _, itemClassID, itemSubClassID = GetItemInfo(itemLink)

                  -- Check if the item is not in the ammunitionExclusions table
                  if not tContains(ammunitionExclusions, name) then
                      if (buyAll and owner == sellerName) or (not buyAll and itemLevel and itemLevel > 70 and buyoutPrice > 0 and buyoutPrice <= 10000) then -- 10000 copper = 1 gold
                          -- Display the confirmation dialog
                          local dialog = StaticPopup_Show("STEALUS_CONFIRM_BUY", itemLink, GetCoinTextureString(buyoutPrice))
                          if dialog then
                              dialog.data = {
                                  auctionType = "list",
                                  index = i,
                                  buyoutPrice = buyoutPrice,
                                  name = name,
                                  itemLevel = itemLevel
                              }

                              -- Pause the scanning process until the player responds to the dialog
                              local playerResponse = coroutine.yield()

                              -- Check the player's response
                              if playerResponse == "yes" then
                                  -- Player clicked "Yes", proceed with the purchase
                                  PlaceAuctionBid(dialog.data.auctionType, dialog.data.index, dialog.data.buyoutPrice)
                                  print(COLOR_ORANGE .. "[Stealus] " .. COLOR_GREEN .. "Bought out item: " .. dialog.data.name .. " (Item Level: " .. dialog.data.itemLevel .. ") for " .. GetCoinTextureString(dialog.data.buyoutPrice) .. COLOR_RESET)
                              else
                                  -- Player clicked "No", continue to the next item
                                  print(COLOR_ORANGE .. "[Stealus] " .. COLOR_RED .. "Skipped item: " .. dialog.data.name .. COLOR_RESET)
                              end
                          end
                      end
                  end
              end
          end
      else
          print(COLOR_ORANGE .. "[Stealus] " .. COLOR_RED .. "Invalid number of auction items." .. COLOR_RESET)
      end
  end

  local function startScanning()
      -- Check if the auction house is still open
      if AuctionFrame and AuctionFrame:IsVisible() then
          -- Set the filters for the query
          local name = nil -- Empty string to match any item name
          local minLevel = 70 -- Minimum item level
          local maxLevel = 80 -- Maximum item level (set to the max level in WoW 3.3.5)
          local invType = nil -- No specific inventory type filter
          local class = nil -- No specific item class filter
          local subclass = nil -- No specific item subclass filter
          local usable = false -- Don't filter by usable items only
          local rarity = nil -- No specific rarity filter
          local exactMatch = false -- Don't require exact name match

          local currentPage = 0 -- Current page counter
          local maxPages = 0 -- Total number of pages

          -- Register the AUCTION_ITEM_LIST_UPDATE event
          eventFrame:RegisterEvent("AUCTION_ITEM_LIST_UPDATE")
          eventFrame:SetScript("OnEvent", function(self, event, ...)
              if event == "AUCTION_ITEM_LIST_UPDATE" then
                  -- Get the total number of auction items for the current query
                  local totalAuctions = GetNumAuctionItems("list")

                  -- Calculate the total number of pages
                  maxPages = math.ceil(totalAuctions / 50) -- Each page displays up to 50 items

                  -- Create a coroutine to handle the scanning process
                  local co = coroutine.create(function()
                      onAuctionItemListUpdate()
                  end)

                  -- Resume the coroutine
                  local success, result = coroutine.resume(co)

                  -- Check if the coroutine has finished
                  if coroutine.status(co) == "dead" then
                      -- Increment the current page counter
                      currentPage = currentPage + 1

                      -- Check if there are more pages to scan
                      if currentPage < maxPages then
                          -- Wait for 1 second and then query the next page
                          setTimer(1, function()
                              QueryAuctionItems(name, minLevel, maxLevel, invType, class, subclass, currentPage, usable, rarity, false, exactMatch)
                          end)
                      else
                          -- All pages have been scanned, unregister the event and start scanning again
                          print(COLOR_ORANGE .. "[Stealus] " .. COLOR_GREEN .. "Scan completed. Repeating." .. COLOR_RESET)
                          setTimer(2, function()
                              startScanning()
                          end)
                          eventFrame:UnregisterEvent("AUCTION_ITEM_LIST_UPDATE")
                      end
                  end
              end
          end)

          -- Query the auction items with the specified filters for the first page
          QueryAuctionItems(name, minLevel, maxLevel, invType, class, subclass, currentPage, usable, rarity, false, exactMatch)
      else
          -- Auction house is closed, stop the scanning process
          print("Auction house closed. Scanning stopped.")
          eventFrame:UnregisterEvent("AUCTION_ITEM_LIST_UPDATE")
      end
  end

  -- Check if the auction house is already open
  if AuctionFrame and AuctionFrame:IsVisible() then
      -- Find and click the "Browse" tab on the Auction House UI
      for i = 1, 3 do -- There are only 3 tabs in WoW 3.3.5 Auction House UI
          local tab = _G["AuctionFrameTab" .. i]
          if tab and tab:GetText() == BROWSE then
              tab:Click()
              break
          end
      end

      -- Start the scanning process
      startScanning()

      -- Sort the auction items by current bid
      SortAuctionItems("list", "bid")
  else
      print(COLOR_ORANGE .. "[Stealus] " .. COLOR_RED .. "Please open the auction house first." .. COLOR_RESET)
  end
end